//connect mongodb database 
module.exports = {
   //url: 'mongodb://localhost:27017/fashionstore'
   url: 'mongodb://padulaguruge:Default123@cluster0-shard-00-00-aa0hd.mongodb.net:27017,cluster0-shard-00-01-aa0hd.mongodb.net:27017,cluster0-shard-00-02-aa0hd.mongodb.net:27017/fashionstore?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority'
}

//datebase name : fashionstorepush 




